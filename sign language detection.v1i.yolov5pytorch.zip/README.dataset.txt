# sign language detection > 2024-08-13 8:53pm
https://universe.roboflow.com/rittik/sign-language-detection-oakou

Provided by a Roboflow user
License: CC BY 4.0

